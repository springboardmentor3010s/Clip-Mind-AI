import {
  require_react
} from "./chunk-AT6LY6XD.js";
import "./chunk-HKJ2B2AA.js";
export default require_react();
