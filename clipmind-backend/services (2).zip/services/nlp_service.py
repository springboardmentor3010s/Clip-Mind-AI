"""
Lightweight, dependency-friendly NLP: extractive TextRank summarization
and frequency-based keyword extraction. No external downloads required
(no NLTK corpora), everything runs on scikit-learn + networkx + regex.
"""
import re
from collections import Counter

import networkx as nx
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

STOPWORDS = set("""
a about above after again against all am an and any are aren't as at be because been
before being below between both but by can't cannot could couldn't did didn't do does
doesn't doing don't down during each few for from further had hadn't has hasn't have
haven't having he he'd he'll he's her here here's hers herself him himself his how
how's i i'd i'll i'm i've if in into is isn't it it's its itself let's me more most
mustn't my myself no nor not of off on once only or other ought our ours ourselves out
over own same shan't she she'd she'll she's should shouldn't so some such than that
that's the their theirs them themselves then there there's these they they'd they'll
they're they've this those through to too under until up very was wasn't we we'd we'll
we're we've were weren't what what's when when's where where's which while who who's
whom why why's with won't would wouldn't you you'd you'll you're you've your yours
yourself yourselves this that these those it its
""".split())


def split_sentences(text: str):
    text = re.sub(r"\s+", " ", text).strip()
    sentences = re.split(r"(?<=[.!?])\s+", text)
    return [s.strip() for s in sentences if len(s.strip()) > 0]


def _tokenize_words(text: str):
    return re.findall(r"[a-zA-Z']+", text.lower())


def textrank_sentences(sentences, top_n=5):
    """Rank sentences by TextRank (TF-IDF similarity graph + PageRank)."""
    if len(sentences) == 0:
        return []
    if len(sentences) <= top_n:
        return list(range(len(sentences)))

    vectorizer = TfidfVectorizer(stop_words="english")
    try:
        tfidf = vectorizer.fit_transform(sentences)
    except ValueError:
        # e.g. sentences are all stopwords/empty after filtering
        return list(range(min(top_n, len(sentences))))

    sim_matrix = cosine_similarity(tfidf)
    for i in range(len(sim_matrix)):
        sim_matrix[i, i] = 0

    graph = nx.from_numpy_array(sim_matrix)
    try:
        scores = nx.pagerank(graph, max_iter=200)
    except nx.PowerIterationFailedConvergence:
        scores = {i: 1.0 for i in range(len(sentences))}

    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    top_indices = sorted([idx for idx, _ in ranked[:top_n]])
    return top_indices


def extract_keywords(text: str, top_n: int = 8):
    """Frequency-based keyword extraction, filtering stopwords and short words."""
    words = [w for w in _tokenize_words(text) if len(w) > 4 and w not in STOPWORDS]
    counts = Counter(words)
    return [{"term": term, "count": count} for term, count in counts.most_common(top_n)]


def build_summary(title: str, duration_fmt: str, full_text: str):
    sentences = split_sentences(full_text)
    word_count = len(re.findall(r"\S+", full_text))

    top_idx = textrank_sentences(sentences, top_n=5)
    bullets = [sentences[i] for i in top_idx] if sentences else []

    keywords = extract_keywords(full_text, top_n=6)
    topics = [k["term"] for k in keywords[:5]] or ["general"]

    abstract_sentences = " ".join(bullets[:2]) if bullets else (sentences[0] if sentences else "")
    abstract = (
        f'"{title}" is a {duration_fmt} recording processed by the ClipMind AI pipeline. '
        f"The session covers {', '.join(topics[:3])}. "
        f"{abstract_sentences}".strip()
    )

    action_items = []
    cue_words = ("should", "need to", "must", "let's", "we will", "next step", "todo", "action")
    for s in sentences:
        low = s.lower()
        if any(c in low for c in cue_words):
            action_items.append(s)
        if len(action_items) >= 3:
            break
    if not action_items:
        action_items = [
            "Review the generated transcript for accuracy.",
            "Confirm the key moments align with the source recording.",
            "Archive this summary alongside the original media file.",
        ]

    bullet_words = len(re.findall(r"\S+", " ".join(bullets))) if bullets else 0
    compression = round((1 - (bullet_words / max(1, word_count))) * 100)

    return {
        "abstract": abstract if abstract.strip() else "No speech content was detected in this recording.",
        "bullets": bullets if bullets else ["No transcript content was available to summarize."],
        "topics": topics,
        "actionItems": action_items,
        "wordCount": word_count,
        "compression": max(0, min(99, compression)),
    }
