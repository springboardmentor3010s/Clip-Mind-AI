from pydantic import BaseModel
from typing import Optional, List


class VideoIdBody(BaseModel):
    videoId: str


class TranscriptSegmentOut(BaseModel):
    id: str
    seconds: float
    time: str
    speaker: str
    text: str


class KeyMomentOut(BaseModel):
    id: str
    seconds: float
    time: str
    title: str
    description: str
    confidence: float
    tag: str


class SummaryOut(BaseModel):
    abstract: str
    bullets: List[str]
    topics: List[str]
    actionItems: List[str]
    wordCount: int
    compression: int
