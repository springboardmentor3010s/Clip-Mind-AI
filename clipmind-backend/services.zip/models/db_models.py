import json
from sqlalchemy import Column, String, Float, Text
from models.database import Base


class Video(Base):
    """
    Stores one uploaded recording plus all pipeline outputs.
    transcript / summary / moments / analytics are stored as JSON text
    and (de)serialized to match the frontend's VideoRecord shape exactly
    (see src/utils/mockEngine.ts on the frontend).
    """
    __tablename__ = "videos"

    id = Column(String, primary_key=True, index=True)
    title = Column(String, nullable=False)
    file_name = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    audio_path = Column(String, nullable=True)
    size_mb = Column(Float, nullable=False)
    duration_seconds = Column(Float, nullable=False, default=0)
    status = Column(String, nullable=False, default="Queued")  # Queued | Processing | Processed | Failed
    created_at = Column(String, nullable=False)
    language = Column(String, nullable=False, default="Unknown")

    transcript_json = Column(Text, nullable=False, default="[]")
    summary_json = Column(Text, nullable=True)
    moments_json = Column(Text, nullable=False, default="[]")
    analytics_json = Column(Text, nullable=True)

    error = Column(Text, nullable=True)

    # ---- helpers -------------------------------------------------------
    def to_record(self) -> dict:
        """Serialize to the exact VideoRecord shape the frontend expects."""
        from services.time_utils import fmt

        return {
            "id": self.id,
            "title": self.title,
            "fileName": self.file_name,
            "sizeMb": round(self.size_mb, 1),
            "durationSeconds": round(self.duration_seconds),
            "duration": fmt(self.duration_seconds),
            "status": self.status,
            "createdAt": self.created_at,
            "language": self.language,
            "transcript": json.loads(self.transcript_json or "[]"),
            "summary": json.loads(self.summary_json) if self.summary_json else None,
            "moments": json.loads(self.moments_json or "[]"),
            "analytics": json.loads(self.analytics_json) if self.analytics_json else None,
        }
