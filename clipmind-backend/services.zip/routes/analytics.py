import json
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from models.database import get_db
from models.db_models import Video
from models.schemas import VideoIdBody
from services import pipeline, analytics_service

router = APIRouter(tags=["analytics"])


@router.get("/analytics")
def get_analytics(videoId: Optional[str] = Query(default=None), db: Session = Depends(get_db)):
    # Per-video analytics.
    if videoId:
        video = db.query(Video).filter(Video.id == videoId).first()
        if not video:
            raise HTTPException(status_code=404, detail="Video not found.")

        if video.analytics_json:
            return {"videoId": video.id, "analytics": json.loads(video.analytics_json)}

        if not video.transcript_json or video.transcript_json == "[]":
            raise HTTPException(status_code=400, detail="Generate the transcript before viewing analytics.")

        # Not computed yet but transcript exists -> compute now (moments are optional at this point).
        video = pipeline.run_analytics(db, video)
        return {"videoId": video.id, "analytics": json.loads(video.analytics_json)}

    # No videoId -> aggregate analytics across every video in the library.
    videos = db.query(Video).order_by(Video.created_at.desc()).all()
    records = [v.to_record() for v in videos]
    return {"videoId": None, "analytics": analytics_service.aggregate_analytics(records)}


@router.post("/generate-analytics")
def generate_analytics(body: VideoIdBody, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == body.videoId).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found.")
    if not video.transcript_json or video.transcript_json == "[]":
        raise HTTPException(status_code=400, detail="Generate the transcript before computing analytics.")

    video = pipeline.run_analytics(db, video)
    return {"videoId": video.id, "analytics": json.loads(video.analytics_json)}
