import os
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session

import config
from models.database import get_db
from models.db_models import Video
from services import ffmpeg_service
from services.time_utils import title_from_file

router = APIRouter(tags=["videos"])


@router.post("/upload")
async def upload_video(file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file provided.")

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in config.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{ext}'. Allowed: {', '.join(sorted(config.ALLOWED_EXTENSIONS))}",
        )

    video_id = str(uuid.uuid4())
    saved_name = f"{video_id}{ext}"
    saved_path = os.path.join(config.UPLOAD_DIR, saved_name)

    size_bytes = 0
    try:
        with open(saved_path, "wb") as out:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size_bytes += len(chunk)
                if size_bytes > config.MAX_UPLOAD_MB * 1024 * 1024:
                    out.close()
                    os.remove(saved_path)
                    raise HTTPException(status_code=413, detail="File exceeds maximum upload size.")
                out.write(chunk)
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Failed to save upload: {e}") from e

    if size_bytes == 0:
        os.remove(saved_path)
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    duration_seconds = ffmpeg_service.probe_duration_seconds(saved_path)
    size_mb = round(size_bytes / 1048576, 1)

    video = Video(
        id=video_id,
        title=title_from_file(file.filename),
        file_name=file.filename,
        file_path=saved_path,
        audio_path=None,
        size_mb=size_mb,
        duration_seconds=duration_seconds,
        status="Queued",
        created_at=datetime.now(timezone.utc).isoformat(),
        language="Unknown",
        transcript_json="[]",
        summary_json=None,
        moments_json="[]",
        analytics_json=None,
    )
    db.add(video)
    db.commit()
    db.refresh(video)

    return video.to_record()


@router.get("/videos")
def list_videos(db: Session = Depends(get_db)):
    videos = db.query(Video).order_by(Video.created_at.desc()).all()
    return [v.to_record() for v in videos]


@router.get("/videos/{video_id}")
def get_video(video_id: str, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found.")
    return video.to_record()


@router.delete("/videos/{video_id}")
def delete_video(video_id: str, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found.")

    for path in (video.file_path, video.audio_path):
        if path and os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass

    db.delete(video)
    db.commit()
    return {"success": True, "id": video_id}
