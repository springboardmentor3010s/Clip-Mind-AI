from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import json

from models.database import get_db
from models.db_models import Video
from models.schemas import VideoIdBody
from services import pipeline

router = APIRouter(tags=["transcript"])


@router.post("/generate-transcript")
def generate_transcript(body: VideoIdBody, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == body.videoId).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found.")
    try:
        video = pipeline.run_transcription(db, video)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Transcription failed: {e}") from e

    return {
        "videoId": video.id,
        "transcript": json.loads(video.transcript_json or "[]"),
        "language": video.language,
    }


@router.get("/transcript/{video_id}")
def get_transcript(video_id: str, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found.")
    return {
        "videoId": video.id,
        "transcript": json.loads(video.transcript_json or "[]"),
        "language": video.language,
    }
