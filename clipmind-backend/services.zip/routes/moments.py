import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from models.database import get_db
from models.db_models import Video
from models.schemas import VideoIdBody
from services import pipeline

router = APIRouter(tags=["moments"])


@router.post("/generate-key-moments")
def generate_key_moments(body: VideoIdBody, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == body.videoId).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found.")
    if not video.transcript_json or video.transcript_json == "[]":
        raise HTTPException(status_code=400, detail="Generate the transcript before extracting key moments.")

    video = pipeline.run_moments(db, video)
    return {"videoId": video.id, "moments": json.loads(video.moments_json or "[]")}


@router.get("/key-moments/{video_id}")
def get_key_moments(video_id: str, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found.")
    return {"videoId": video.id, "moments": json.loads(video.moments_json or "[]")}
