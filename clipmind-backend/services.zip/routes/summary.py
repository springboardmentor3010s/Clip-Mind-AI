from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import json

from models.database import get_db
from models.db_models import Video
from models.schemas import VideoIdBody
from services import pipeline

router = APIRouter(tags=["summary"])


@router.post("/generate-summary")
def generate_summary(body: VideoIdBody, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == body.videoId).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found.")
    if not video.transcript_json or video.transcript_json == "[]":
        raise HTTPException(status_code=400, detail="Generate the transcript before generating a summary.")

    video = pipeline.run_summary(db, video)
    return {"videoId": video.id, "summary": json.loads(video.summary_json)}


@router.get("/summary/{video_id}")
def get_summary(video_id: str, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found.")
    return {
        "videoId": video.id,
        "summary": json.loads(video.summary_json) if video.summary_json else None,
    }
