import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { FiFileText, FiSearch, FiDownload } from "react-icons/fi";
import { useWorkspace } from "../../context/WorkspaceContext";
import { EmptyState } from "../../components/EmptyState";
import { VideoSelect } from "../../components/VideoSelect";

export const Route = createFileRoute("/_authenticated/transcript")({
  head: () => ({
    meta: [
      { title: "Transcript — ClipMind AI" },
      { name: "description", content: "Timestamp-aligned transcript segments generated from your uploaded recording." },
      { property: "og:title", content: "Transcript — ClipMind AI" },
      { property: "og:description", content: "Search and review speaker-labelled transcript segments." },
    ],
  }),
  component: TranscriptPage,
});

function TranscriptPage() {
  const { active } = useWorkspace();
  const [query, setQuery] = useState("");
  const [speaker, setSpeaker] = useState("All");

  const speakers = useMemo(
    () => ["All", ...Array.from(new Set(active?.transcript.map((s) => s.speaker) ?? []))],
    [active],
  );

  const rows = useMemo(() => {
    const segs = active?.transcript ?? [];
    const q = query.trim().toLowerCase();
    return segs.filter(
      (s) => (speaker === "All" || s.speaker === speaker) && (!q || s.text.toLowerCase().includes(q)),
    );
  }, [active, query, speaker]);

  if (!active) {
    return (
      <EmptyState
        icon={<FiFileText />}
        title="No transcript yet"
        description="Transcript segments appear here once a recording has been processed."
      />
    );
  }

  const download = () => {
    const text = active.transcript.map((s) => `[${s.time}] ${s.speaker}: ${s.text}`).join("\n");
    const url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${active.title}-transcript.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl">Transcript</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {active.transcript.length} segments · {active.language} · {active.duration}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <VideoSelect />
          <button onClick={download} className="h-10 inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3 text-sm hover:bg-muted">
            <FiDownload /> Export
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-56">
          <FiSearch className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search transcript…"
            className="h-10 w-full rounded-xl border border-border bg-card pl-9 pr-3 text-sm outline-none focus:ring-focus"
          />
        </div>
        <select
          value={speaker}
          onChange={(e) => setSpeaker(e.target.value)}
          className="h-10 rounded-xl border border-border bg-card px-3 text-sm outline-none focus:ring-focus"
        >
          {speakers.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      <div className="divide-y divide-border rounded-2xl border border-border bg-card">
        {rows.map((s) => (
          <div key={s.id} className="flex gap-4 p-4 hover:bg-muted/40">
            <span className="font-mono-num shrink-0 text-xs text-primary">{s.time}</span>
            <div>
              <div className="text-xs uppercase tracking-wide text-muted-foreground">{s.speaker}</div>
              <p className="mt-1 text-sm leading-relaxed">{s.text}</p>
            </div>
          </div>
        ))}
        {rows.length === 0 && <div className="p-8 text-center text-sm text-muted-foreground">No segments match the current filters.</div>}
      </div>
    </div>
  );
}
