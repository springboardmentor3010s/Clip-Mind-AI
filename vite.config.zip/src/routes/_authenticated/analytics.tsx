import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { FiBarChart2 } from "react-icons/fi";
import { useWorkspace } from "../../context/WorkspaceContext";
import { EmptyState } from "../../components/EmptyState";
import { fmt } from "../../utils/mockEngine";

export const Route = createFileRoute("/_authenticated/analytics")({
  head: () => ({
    meta: [
      { title: "Analytics — ClipMind AI" },
      { name: "description", content: "Speaker distribution, keyword frequency and engagement curves computed from your processed recordings." },
      { property: "og:title", content: "Analytics — ClipMind AI" },
      { property: "og:description", content: "Per-recording analytics with dynamic scope and segment filters." },
    ],
  }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const { videos, activeId } = useWorkspace();
  const [scope, setScope] = useState<string>("active");
  const [half, setHalf] = useState<"all" | "first" | "second">("all");

  const processed = videos.filter((v) => v.analytics);

  const record = useMemo(() => {
    if (scope === "all") return null;
    const id = scope === "active" ? activeId : scope;
    return processed.find((v) => v.id === id) ?? processed[0] ?? null;
  }, [scope, activeId, processed]);

  const aggregate = useMemo(() => {
    if (scope !== "all") return null;
    const keywords: Record<string, number> = {};
    processed.forEach((v) => v.analytics?.keywords.forEach((k) => { keywords[k.term] = (keywords[k.term] ?? 0) + k.count; }));
    return {
      keywords: Object.entries(keywords).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([term, count]) => ({ term, count })),
      metrics: [
        { label: "Recordings", value: String(processed.length) },
        { label: "Total duration", value: fmt(processed.reduce((n, v) => n + v.durationSeconds, 0)) },
        { label: "Key moments", value: String(processed.reduce((n, v) => n + v.moments.length, 0)) },
        { label: "Segments", value: String(processed.reduce((n, v) => n + v.transcript.length, 0)) },
      ],
    };
  }, [scope, processed]);

  if (processed.length === 0) {
    return (
      <EmptyState
        icon={<FiBarChart2 />}
        title="No analytics available"
        description="Analytics are computed during processing. Upload a recording to generate them."
      />
    );
  }

  const a = record?.analytics ?? null;
  const timeline = a
    ? a.sentimentTimeline.filter((p) => {
        if (!record || half === "all") return true;
        const mid = record.durationSeconds / 2;
        return half === "first" ? p.seconds <= mid : p.seconds > mid;
      })
    : [];

  const metrics = aggregate?.metrics ?? a?.metrics ?? [];
  const keywords = aggregate?.keywords ?? a?.keywords ?? [];

  const path = timeline.length
    ? timeline
        .map((p, i) => `${(i / Math.max(1, timeline.length - 1)) * 100},${60 - p.value * 55}`)
        .join(" ")
    : "";

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl">Analytics</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {scope === "all" ? "Aggregated across all processed recordings" : record?.title}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <select value={scope} onChange={(e) => setScope(e.target.value)} className="h-10 max-w-64 rounded-xl border border-border bg-card px-3 text-sm outline-none focus:ring-focus">
            <option value="active">Active recording</option>
            <option value="all">All recordings</option>
            {processed.map((v) => <option key={v.id} value={v.id}>{v.title}</option>)}
          </select>
          <select
            value={half}
            onChange={(e) => setHalf(e.target.value as typeof half)}
            disabled={scope === "all"}
            className="h-10 rounded-xl border border-border bg-card px-3 text-sm outline-none focus:ring-focus disabled:opacity-50"
          >
            <option value="all">Full timeline</option>
            <option value="first">First half</option>
            <option value="second">Second half</option>
          </select>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {metrics.map((m) => (
          <div key={m.label} className="rounded-2xl border border-border bg-card p-5">
            <div className="text-[11px] uppercase tracking-widest text-muted-foreground">{m.label}</div>
            <div className="mt-1.5 font-display text-xl">{m.value}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-2xl border border-border bg-card p-6">
          <h2 className="font-display text-lg">Engagement curve</h2>
          {scope === "all" ? (
            <p className="mt-3 text-sm text-muted-foreground">Select a single recording to view its timeline curve.</p>
          ) : (
            <svg viewBox="0 0 100 60" preserveAspectRatio="none" className="mt-4 h-40 w-full">
              <polyline points={path} fill="none" stroke="currentColor" className="text-primary" strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
            </svg>
          )}
        </section>

        <section className="rounded-2xl border border-border bg-card p-6">
          <h2 className="font-display text-lg">Speaker distribution</h2>
          <div className="mt-4 space-y-3">
            {(a?.speakerShare ?? []).map((s) => (
              <div key={s.speaker}>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{s.speaker}</span><span className="font-mono-num">{s.pct}%</span>
                </div>
                <div className="mt-1 h-2 rounded-full bg-muted">
                  <div className="h-full rounded-full bg-gradient-primary" style={{ width: `${s.pct}%` }} />
                </div>
              </div>
            ))}
            {scope === "all" && <p className="text-sm text-muted-foreground">Select a single recording to view speaker split.</p>}
          </div>
        </section>
      </div>

      <section className="rounded-2xl border border-border bg-card p-6">
        <h2 className="font-display text-lg">Keyword frequency</h2>
        <div className="mt-4 space-y-2">
          {keywords.map((k) => (
            <div key={k.term} className="flex items-center gap-3">
              <span className="w-40 truncate text-sm text-muted-foreground">{k.term}</span>
              <div className="h-2 flex-1 rounded-full bg-muted">
                <div className="h-full rounded-full bg-gradient-primary" style={{ width: `${(k.count / (keywords[0]?.count || 1)) * 100}%` }} />
              </div>
              <span className="font-mono-num w-8 text-right text-xs text-muted-foreground">{k.count}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
