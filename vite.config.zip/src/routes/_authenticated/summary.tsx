import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { FiCpu, FiCopy } from "react-icons/fi";
import { useWorkspace } from "../../context/WorkspaceContext";
import { EmptyState } from "../../components/EmptyState";
import { VideoSelect } from "../../components/VideoSelect";
import { useToast } from "../../context/ToastContext";

export const Route = createFileRoute("/_authenticated/summary")({
  head: () => ({
    meta: [
      { title: "AI Summary — ClipMind AI" },
      { name: "description", content: "Structured AI summary with abstract, key findings, topics and follow-up actions for your processed recording." },
      { property: "og:title", content: "AI Summary — ClipMind AI" },
      { property: "og:description", content: "Abstract, key findings and topic labels generated from your transcript." },
    ],
  }),
  component: SummaryPage,
});

function SummaryPage() {
  const { active } = useWorkspace();
  const { toast } = useToast();

  if (!active?.summary) {
    return (
      <EmptyState
        icon={<FiCpu />}
        title="No summary generated yet"
        description="Upload and process a recording to generate its abstract, key findings and topic labels."
      />
    );
  }

  const s = active.summary;

  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl">AI Summary</h1>
          <p className="mt-1 text-sm text-muted-foreground">{active.title} · {active.duration}</p>
        </div>
        <VideoSelect />
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        {[
          { label: "Transcribed words", value: s.wordCount },
          { label: "Compression", value: `${s.compression}%` },
          { label: "Topics detected", value: s.topics.length },
        ].map((m) => (
          <div key={m.label} className="rounded-2xl border border-border bg-card p-4">
            <div className="text-[11px] uppercase tracking-widest text-muted-foreground">{m.label}</div>
            <div className="mt-1.5 font-display text-xl">{m.value}</div>
          </div>
        ))}
      </div>

      <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-border bg-card p-6">
        <div className="flex items-start justify-between gap-4">
          <h2 className="font-display text-lg">Abstract</h2>
          <button
            onClick={() => { navigator.clipboard.writeText(s.abstract); toast("Abstract copied", "success"); }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-xs text-muted-foreground hover:text-foreground"
          >
            <FiCopy /> Copy
          </button>
        </div>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.abstract}</p>
      </motion.section>

      <section className="rounded-2xl border border-border bg-card p-6">
        <h2 className="font-display text-lg">Key findings</h2>
        <ul className="mt-3 space-y-2.5">
          {s.bullets.map((b, i) => (
            <li key={i} className="flex gap-3 text-sm">
              <span className="font-mono-num text-xs text-primary">{String(i + 1).padStart(2, "0")}</span>
              <span className="text-muted-foreground">{b}</span>
            </li>
          ))}
        </ul>
      </section>

      <div className="grid gap-3 md:grid-cols-2">
        <section className="rounded-2xl border border-border bg-card p-6">
          <h2 className="font-display text-lg">Topics</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {s.topics.map((t) => (
              <span key={t} className="rounded-lg border border-border bg-muted px-2.5 py-1 text-xs text-muted-foreground">{t}</span>
            ))}
          </div>
        </section>
        <section className="rounded-2xl border border-border bg-card p-6">
          <h2 className="font-display text-lg">Follow-up actions</h2>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            {s.actionItems.map((a) => <li key={a}>· {a}</li>)}
          </ul>
        </section>
      </div>
    </div>
  );
}
