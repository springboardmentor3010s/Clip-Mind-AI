import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { FiArrowRight, FiCpu, FiFileText, FiLayers, FiBarChart2, FiUploadCloud, FiSearch } from "react-icons/fi";
import { ThemeToggle } from "../components/ThemeToggle";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ClipMind AI — Video Summarization Research Platform" },
      { name: "description", content: "ClipMind AI is a research platform that turns lecture and seminar recordings into aligned transcripts, structured summaries, key moments and analytics." },
      { property: "og:title", content: "ClipMind AI — Video Summarization Research Platform" },
      { property: "og:description", content: "Transcripts, structured summaries, timestamped key moments and analytics for research and teaching recordings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const features = [
  { icon: FiFileText, title: "Timestamp-aligned transcript", desc: "Speech is segmented by speaker turn and aligned to the media timeline for precise citation." },
  { icon: FiCpu, title: "Structured AI summary", desc: "An abstract, key findings, topic labels and follow-up actions generated from the full transcript." },
  { icon: FiLayers, title: "Key moment extraction", desc: "Salient segments are ranked and exposed as jump-to-timestamp markers on the recording." },
  { icon: FiBarChart2, title: "Session analytics", desc: "Speaker distribution, keyword frequency and engagement curves computed per recording." },
];

const steps = [
  { n: "01", title: "Upload a recording", desc: "Submit a lecture, seminar or interview file to the workspace." },
  { n: "02", title: "Automated processing", desc: "Transcription, summarisation, moment extraction and analytics run in sequence." },
  { n: "03", title: "Review and navigate", desc: "Read the summary, jump to any moment on the timeline and filter your archive." },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background bg-mesh">
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-5 py-3.5">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <FiCpu className="text-white text-sm" />
            </div>
            <div className="leading-tight">
              <div className="font-display text-base">ClipMind AI</div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Video Summarization Research</div>
            </div>
          </Link>
          <nav className="ml-auto hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <a href="#features" className="hover:text-foreground">Capabilities</a>
            <a href="#workflow" className="hover:text-foreground">Workflow</a>
          </nav>
          <div className="ml-auto flex items-center gap-2 md:ml-4">
            <ThemeToggle />
            <Link to="/login" className="h-10 px-3.5 inline-flex items-center rounded-xl text-sm text-muted-foreground hover:text-foreground">Sign in</Link>
            <Link to="/register" className="h-10 px-4 inline-flex items-center rounded-xl bg-gradient-primary text-sm font-medium text-white">Create account</Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative border-b border-border/70">
        <div className="mx-auto max-w-6xl px-5 py-20 md:py-28">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-[11px] uppercase tracking-widest text-muted-foreground">
              Infosys Internship · Milestone 2 &amp; 3
            </div>
            <h1 className="mt-6 font-display text-4xl leading-[1.1] md:text-6xl">
              A research workspace for <span className="text-gradient">video understanding</span>.
            </h1>
            <p className="mt-5 max-w-2xl text-base text-muted-foreground md:text-lg">
              ClipMind AI processes recorded lectures, seminars and interviews into aligned transcripts,
              structured summaries, ranked key moments and per-session analytics — all reproducible from
              a single upload.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/register" className="h-11 inline-flex items-center gap-2 rounded-xl bg-gradient-primary px-5 text-sm font-medium text-white">
                Open the workspace <FiArrowRight />
              </Link>
              <Link to="/login" className="h-11 inline-flex items-center gap-2 rounded-xl border border-border bg-card px-5 text-sm">
                Sign in
              </Link>
            </div>
          </motion.div>

          <div className="mt-14 grid gap-3 sm:grid-cols-3">
            {[
              { k: "Pipeline stages", v: "5" },
              { k: "Roles supported", v: "Researcher · Educator · Administrator" },
              { k: "Backend target", v: "FastAPI service layer" },
            ].map((s) => (
              <div key={s.k} className="rounded-xl border border-border bg-card/60 p-4">
                <div className="text-[11px] uppercase tracking-widest text-muted-foreground">{s.k}</div>
                <div className="mt-1.5 font-display text-lg">{s.v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="border-b border-border/70">
        <div className="mx-auto max-w-6xl px-5 py-20">
          <h2 className="font-display text-3xl">Capabilities</h2>
          <p className="mt-2 max-w-2xl text-muted-foreground">Every output is generated from your own upload — nothing is pre-filled.</p>
          <div className="mt-10 grid gap-4 md:grid-cols-2">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="rounded-2xl border border-border bg-card p-6"
              >
                <div className="h-10 w-10 rounded-lg border border-border bg-muted flex items-center justify-center text-primary">
                  <f.icon />
                </div>
                <h3 className="mt-4 font-display text-lg">{f.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="workflow" className="border-b border-border/70">
        <div className="mx-auto max-w-6xl px-5 py-20">
          <h2 className="font-display text-3xl">How it works</h2>
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {steps.map((s) => (
              <div key={s.n} className="rounded-2xl border border-border bg-card p-6">
                <div className="font-mono-num text-xs text-primary">{s.n}</div>
                <h3 className="mt-3 font-display text-lg">{s.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 flex flex-wrap gap-3 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2"><FiUploadCloud /> Upload</span>
            <span className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2"><FiFileText /> Transcript</span>
            <span className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2"><FiCpu /> Summary</span>
            <span className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2"><FiLayers /> Key moments</span>
            <span className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2"><FiSearch /> Analytics</span>
          </div>
        </div>
      </section>

      <footer className="mx-auto max-w-6xl px-5 py-10 text-sm text-muted-foreground">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="font-display text-base text-foreground">ClipMind AI</div>
            <p className="mt-1">AI-powered video summarization platform · academic project build.</p>
          </div>
          <div className="flex items-center gap-5">
            <Link to="/login" className="hover:text-foreground">Sign in</Link>
            <Link to="/register" className="hover:text-foreground">Create account</Link>
            <ThemeToggle />
          </div>
        </div>
      </footer>
    </div>
  );
}
