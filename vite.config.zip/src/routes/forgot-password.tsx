import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { FiMail, FiCheckCircle } from "react-icons/fi";
import { Input } from "../components/TextInput";
import { Button } from "../components/PrimaryButton";
import { AuthShell } from "../components/AuthShell";

export const Route = createFileRoute("/forgot-password")({ component: ForgotPage });

function ForgotPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  return (
    <AuthShell title="Reset your password" subtitle="We'll email you a secure reset link.">
      {sent ? (
        <div className="text-center py-4">
          <div className="mx-auto h-14 w-14 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-4">
            <FiCheckCircle className="text-2xl" />
          </div>
          <h3 className="text-lg font-semibold mb-1">Check your inbox</h3>
          <p className="text-sm text-muted-foreground">If <span className="text-foreground">{email}</span> exists, a reset link is on its way.</p>
        </div>
      ) : (
        <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="space-y-4">
          <Input label="Email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} icon={<FiMail />} placeholder="you@company.com" />
          <Button type="submit" className="w-full">Send reset link</Button>
        </form>
      )}
      <p className="mt-6 text-center text-sm text-muted-foreground">
        Remember it? <Link to="/login" className="text-primary font-medium hover:underline">Back to sign in</Link>
      </p>
    </AuthShell>
  );
}
