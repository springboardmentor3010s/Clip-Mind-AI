import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Role = "Researcher" | "Educator" | "Administrator";

export const ROLES: Role[] = ["Researcher", "Educator", "Administrator"];

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  institution?: string;
  avatar?: string;
}

interface AuthContextValue {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  login: (email: string, password: string, role?: Role) => Promise<User>;
  register: (name: string, email: string, password: string, role: Role) => Promise<User>;
  updateUser: (patch: Partial<User>) => void;
  logout: () => void;
  currentUser: () => User | null;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);
const STORAGE_KEY = "clipmind_user";

function inferRole(email: string): Role {
  if (email.includes("admin")) return "Administrator";
  if (email.includes("edu") || email.includes("faculty")) return "Educator";
  return "Researcher";
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setUser(JSON.parse(raw));
    } catch { /* ignore */ }
    setLoading(false);
  }, []);

  const persist = (u: User | null) => {
    setUser(u);
    if (u) localStorage.setItem(STORAGE_KEY, JSON.stringify(u));
    else localStorage.removeItem(STORAGE_KEY);
  };

  const login = async (email: string, _password: string, role?: Role) => {
    await new Promise((r) => setTimeout(r, 450));
    const name = email.split("@")[0].replace(/[._]/g, " ").replace(/\b\w/g, (m) => m.toUpperCase());
    const u: User = { id: crypto.randomUUID(), name, email, role: role ?? inferRole(email) };
    persist(u);
    return u;
  };

  const register = async (name: string, email: string, _password: string, role: Role) => {
    await new Promise((r) => setTimeout(r, 550));
    const u: User = { id: crypto.randomUUID(), name, email, role };
    persist(u);
    return u;
  };

  const updateUser = (patch: Partial<User>) => {
    if (!user) return;
    persist({ ...user, ...patch });
  };

  const logout = () => persist(null);
  const currentUser = () => user;

  return (
    <AuthContext.Provider
      value={{ user, isAuthenticated: !!user, loading, login, register, updateUser, logout, currentUser }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

export function roleHomePath(_role: Role): string {
  return "/dashboard";
}
