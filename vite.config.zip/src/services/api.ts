import axios from "axios";

/**
 * Axios instance ready for FastAPI backend.
 * Configure VITE_API_URL in env; defaults to /api for same-origin dev.
 */
export const api = axios.create({
  baseURL: (import.meta as any).env?.VITE_API_URL || "/api",
  headers: { "Content-Type": "application/json" },
  timeout: 0,
});

api.interceptors.request.use((config) => {
  try {
    const raw = localStorage.getItem("clipmind_user");
    if (raw) {
      const u = JSON.parse(raw);
      if (u?.token) config.headers.Authorization = `Bearer ${u.token}`;
    }
  } catch {}
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (error) => Promise.reject(error),
);
