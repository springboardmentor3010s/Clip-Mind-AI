import Link from "next/link";

export default function About() {
  return (
    <main>
      <nav className="navbar">
        <Link href="/" className="brand">ClipMind AI</Link>
        <div className="navlinks">
          <Link href="/">Home</Link>
          <Link href="/login">Login</Link>
          <Link href="/register" className="btn">Get Started</Link>
        </div>
      </nav>

      <section className="about-hero">
        <span className="eyebrow">ABOUT CLIPMIND AI</span>
        <h1>Make long-form video content easier to understand.</h1>
        <p>
          ClipMind AI is an AI-powered video summarization and key moments
          detection platform for creators, learners, educators and administrators.
        </p>
      </section>

      <section className="about-grid">
        <article><span>01</span><h2>Content Creators</h2><p>Upload videos, generate transcripts and summaries, identify highlights and review content analytics.</p></article>
        <article><span>02</span><h2>Learners</h2><p>Watch videos, read summaries, search transcripts, explore key moments and bookmark useful content.</p></article>
        <article><span>03</span><h2>Educators</h2><p>Transform lectures into concise learning resources and review educational content insights.</p></article>
        <article><span>04</span><h2>Administrators</h2><p>Manage users, monitor activity, review analytics and maintain platform operations.</p></article>
      </section>

      <section className="technology">
        <h2>Platform capabilities</h2>
        <div className="tech-list">
          <span>Video Upload</span><span>Speech-to-Text</span><span>AI Summaries</span>
          <span>Key Moments</span><span>Keyword Extraction</span><span>Analytics</span>
          <span>Role-Based Access</span><span>Activity History</span>
        </div>
      </section>
    </main>
  );
}
