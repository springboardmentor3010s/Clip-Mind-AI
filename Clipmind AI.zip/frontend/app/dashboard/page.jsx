"use client";
import {useEffect,useState} from "react"; import axios from "axios"; import Link from "next/link";
const API="http://127.0.0.1:8000";
export default function Dashboard(){
 const [user,setUser]=useState(null),[stats,setStats]=useState({}),[videos,setVideos]=useState([]),[msg,setMsg]=useState("");
 useEffect(()=>{const u=JSON.parse(localStorage.getItem("user")||"null");setUser(u);const token=localStorage.getItem("token");if(!token)return;const h={headers:{Authorization:`Bearer ${token}`}};Promise.all([axios.get(API+"/dashboard/stats",h),axios.get(API+"/videos",h)]).then(([a,b])=>{setStats(a.data);setVideos(b.data)}).catch(()=>{})},[]);
 async function process(id){const token=localStorage.getItem("token");setMsg("Processing...");try{await axios.post(`${API}/videos/${id}/process`,{}, {headers:{Authorization:`Bearer ${token}`}});setMsg("Video processed successfully.");}catch(e){setMsg(e.response?.data?.detail||"Processing failed")}}
 if(!user)return <main className="page"><p>Please login first.</p><Link href="/login">Login</Link></main>;
 return <main className="page"><nav className="top"><b>ClipMind AI</b><div>{user.full_name} · <strong>{user.role}</strong><button onClick={()=>{localStorage.clear();location.href="/login"}}>Logout</button></div></nav>
 <section className="content"><h1>{user.role==="creator"?"Creator":user.role==="educator"?"Educator":user.role==="admin"?"Administrator":"Learner"} Dashboard</h1><p className="muted">Welcome back, {user.full_name}. Your real platform activity appears below.</p>
 <div className="cards"><div><small>Videos</small><b>{stats.videos||0}</b></div><div><small>Summaries</small><b>{stats.summaries||0}</b></div><div><small>Bookmarks</small><b>{stats.bookmarks||0}</b></div><div><small>Activities</small><b>{stats.activities||0}</b></div></div>
 {["creator","educator","admin"].includes(user.role)&&<Link className="primary" href="/upload">Upload Video</Link>}
 {msg&&<p className="notice">{msg}</p>}<h2>Videos</h2><div className="video-list">{videos.map(v=><article key={v.id}><div><h3>{v.title}</h3><span>{v.status}</span></div><div>{["creator","educator","admin"].includes(user.role)&&<button onClick={()=>process(v.id)}>Generate AI Results</button>}<Link href={`/watch?id=${v.id}`}>Open</Link></div></article>)}</div>
 </section></main>
}
