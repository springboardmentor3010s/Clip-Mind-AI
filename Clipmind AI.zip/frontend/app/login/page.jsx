"use client";
import {useState} from "react"; import {useRouter} from "next/navigation";
import axios from "axios"; import Link from "next/link";
export default function Login(){
 const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState(""); const router=useRouter();
 async function submit(e){e.preventDefault();setError("");const f=new FormData();f.append("email",email);f.append("password",password);
 try{const r=await axios.post("http://127.0.0.1:8000/auth/login",f);localStorage.setItem("token",r.data.access_token);localStorage.setItem("user",JSON.stringify(r.data.user));router.push("/dashboard");}catch(x){setError(x.response?.data?.detail||"Login failed")}}
 return <main className="auth"><form onSubmit={submit} className="form"><h1>Welcome back</h1><p>Sign in to ClipMind AI</p>{error&&<div className="error">{error}</div>}<input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/><input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} required/><button>Login</button><small>Don't have an account? <Link href="/register">Register</Link></small></form></main>
}
