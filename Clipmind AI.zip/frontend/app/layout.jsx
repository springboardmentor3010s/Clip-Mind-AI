import "./globals.css";
export const metadata = { title: "ClipMind AI", description: "Video intelligence platform" };
export default function RootLayout({children}) {
  return <html lang="en"><body>{children}</body></html>;
}
