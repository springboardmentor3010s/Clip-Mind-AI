import Link from "next/link";
export default function Home() {
  return <main className="landing">
    <nav><b>ClipMind AI</b><div><Link href="/about">About</Link><Link href="/login">Login</Link><Link href="/register" className="btn">Get Started</Link></div></nav>
    <section className="hero">
      <div><span className="pill">AI VIDEO INTELLIGENCE</span>
      <h1>Turn long videos into <span>clear insights.</span></h1>
      <p>Upload a video, generate its transcript and AI summary, discover key moments, extract keywords, and understand your content faster.</p>
      <Link href="/register" className="primary">Start with ClipMind AI →</Link></div>
      <div className="hero-card"><div className="fake-video">▶</div><div className="stats"><b>AI Summary</b><span>Key moments · Transcript · Keywords</span></div></div>
    </section>
  </main>;
}
