"use client";
import {useState} from "react"; import {useRouter} from "next/navigation"; import axios from "axios";
export default function Upload(){const [title,setTitle]=useState(""),[file,setFile]=useState(null),[msg,setMsg]=useState("");const router=useRouter();
async function submit(e){e.preventDefault();const f=new FormData();f.append("title",title);f.append("file",file);try{await axios.post("http://127.0.0.1:8000/videos/upload",f,{headers:{Authorization:`Bearer ${localStorage.getItem("token")}`}});setMsg("Uploaded successfully.");setTimeout(()=>router.push("/dashboard"),700)}catch(x){setMsg(x.response?.data?.detail||"Upload failed")}}
return <main className="auth"><form className="form" onSubmit={submit}><h1>Upload Video</h1><input placeholder="Video title" value={title} onChange={e=>setTitle(e.target.value)} required/><input type="file" accept="video/*" onChange={e=>setFile(e.target.files[0])} required/><button>Upload</button>{msg&&<p>{msg}</p>}</form></main>}
