# ClipMind AI — Fixed Complete Project

This rebuilt version follows the supplied ClipMind AI requirements: authentication and role-based access, video upload, transcript workflow, AI summary workflow, key moments, analytics, Docker-ready deployment, and role-specific functionality.

## What was fixed
- Removed the bcrypt/passlib dependency that caused `(trapped) error reading bcrypt version`.
- Passwords now use Python standard-library PBKDF2-HMAC-SHA256 hashing.
- Registration returns the actual backend error in the UI.
- Public registration supports Creator, Learner and Educator; Administrator is seeded securely.
- Added automatic demo administrator on first backend startup.
- Added `/about` page.
- Added Admin panel and analytics endpoints.
- Kept SQLite as the easy local default and PostgreSQL as a supported configuration.

## Run backend
```powershell
cd backend
python -m venv venv
.\venv\Scripts\Activate
pip install -r requirements.txt
uvicorn main:app --reload
```
Backend: http://127.0.0.1:8000
Swagger: http://127.0.0.1:8000/docs

## Run frontend in a second terminal
```powershell
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:3000

## Demo administrator
Email: `admin@clipmind.local`
Password: `Admin@123`

Change these in `.env` for a real deployment.

## Important
The included AI service is a lightweight demonstration adapter so the project starts without downloading multi-gigabyte AI models. The PDF's production target calls for Whisper and NLP summarization; those can be integrated into `backend/ai_service.py` after the core platform is verified.
