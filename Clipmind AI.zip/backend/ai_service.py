import re

def demo_transcript(title: str) -> str:
    return (
        f"This is the generated transcript for {title}. "
        "The video introduces the main topic, explains important concepts, "
        "and concludes with practical takeaways. Replace this demo adapter "
        "with OpenAI Whisper for real speech-to-text processing."
    )

def summarize(text: str):
    sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', text) if s.strip()]
    short = " ".join(sentences[:2]) if sentences else text[:300]
    detailed = " ".join(sentences[:6]) if sentences else text
    words = re.findall(r"[A-Za-z]{4,}", text.lower())
    stop = {"this","that","with","from","video","will","have","the","and","for"}
    freq = {}
    for w in words:
        if w not in stop:
            freq[w] = freq.get(w, 0) + 1
    keywords = sorted(freq, key=freq.get, reverse=True)[:8]
    return short, detailed, keywords

def detect_key_moments(text: str):
    sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', text) if s.strip()]
    moments = []
    for i, sentence in enumerate(sentences[:5]):
        moments.append({
            "timestamp": float(i * 30),
            "title": f"Key Moment {i+1}",
            "description": sentence
        })
    return moments
