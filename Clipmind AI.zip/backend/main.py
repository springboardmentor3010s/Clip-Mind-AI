import os
from pathlib import Path
import shutil
from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from database import Base, engine, get_db
from models import User, Video, Transcript, Summary, KeyMoment, Bookmark, Activity
from auth import hash_password, verify_password, create_token, get_current_user, require_roles
from ai_service import demo_transcript, summarize, detect_key_moments

Base.metadata.create_all(bind=engine)
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

app = FastAPI(title="ClipMind AI API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
)
app.mount("/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads")

@app.on_event("startup")
def seed_admin():
    db = next(get_db())
    try:
        email = os.getenv("ADMIN_EMAIL", "admin@clipmind.local")
        password = os.getenv("ADMIN_PASSWORD", "Admin@123")
        existing = db.query(User).filter(User.email == email).first()
        if not existing:
            db.add(User(full_name="ClipMind Administrator", email=email, password_hash=hash_password(password), role="admin"))
            db.commit()
    finally:
        db.close()


@app.get("/")
def root():
    return {"message": "ClipMind AI API", "status": "running"}

@app.post("/auth/register")
def register(full_name: str = Form(...), email: str = Form(...),
             password: str = Form(...), role: str = Form("learner"),
             db: Session = Depends(get_db)):
    role = role.lower()
    if role not in {"creator", "learner", "educator"}:
        raise HTTPException(400, "Public registration is available for Creator, Learner and Educator")
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(400, "Email already registered")
    user = User(full_name=full_name, email=email,
                password_hash=hash_password(password), role=role)
    db.add(user); db.commit(); db.refresh(user)
    return {"access_token": create_token(user), "user": user_data(user)}

@app.post("/auth/login")
def login(email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return {"access_token": create_token(user), "user": user_data(user)}

@app.get("/auth/me")
def me(user=Depends(get_current_user)):
    return user_data(user)

@app.post("/videos/upload")
def upload_video(file: UploadFile = File(...), title: str = Form(...),
                 user=Depends(require_roles("creator","educator","admin")),
                 db: Session = Depends(get_db)):
    allowed = {".mp4",".mov",".avi",".mkv",".webm"}
    ext = Path(file.filename).suffix.lower()
    if ext not in allowed:
        raise HTTPException(400, "Unsupported video format")
    safe_name = f"{user.id}_{Path(file.filename).name}"
    path = UPLOAD_DIR / safe_name
    with path.open("wb") as out:
        shutil.copyfileobj(file.file, out)
    video = Video(title=title, filename=safe_name, owner_id=user.id, status="uploaded")
    db.add(video)
    db.add(Activity(user_id=user.id, action=f"Uploaded video: {title}"))
    db.commit(); db.refresh(video)
    return video_data(video)

@app.get("/videos")
def videos(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = db.query(Video).order_by(Video.created_at.desc()).all()
    return [video_data(v) for v in rows]

@app.get("/videos/{video_id}")
def video(video_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    v = db.get(Video, video_id)
    if not v: raise HTTPException(404, "Video not found")
    return video_data(v)

@app.post("/videos/{video_id}/process")
def process_video(video_id: int, db: Session = Depends(get_db),
                  user=Depends(require_roles("creator","educator","admin"))):
    v = db.get(Video, video_id)
    if not v: raise HTTPException(404, "Video not found")
    text = demo_transcript(v.title)
    short, detailed, keywords = summarize(text)
    old_t = db.query(Transcript).filter(Transcript.video_id == video_id).first()
    if old_t: old_t.text = text
    else: db.add(Transcript(video_id=video_id, text=text))
    old_s = db.query(Summary).filter(Summary.video_id == video_id).first()
    if old_s:
        old_s.short_summary, old_s.detailed_summary, old_s.keywords = short, detailed, ",".join(keywords)
    else:
        db.add(Summary(video_id=video_id, short_summary=short,
                       detailed_summary=detailed, keywords=",".join(keywords)))
    db.query(KeyMoment).filter(KeyMoment.video_id == video_id).delete()
    for m in detect_key_moments(text):
        db.add(KeyMoment(video_id=video_id, **m))
    v.status = "processed"
    db.add(Activity(user_id=user.id, action=f"Processed video: {v.title}"))
    db.commit()
    return {"status":"processed","transcript":text,"short_summary":short,
            "detailed_summary":detailed,"keywords":keywords,
            "key_moments":detect_key_moments(text)}

@app.get("/videos/{video_id}/transcript")
def transcript(video_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    row = db.query(Transcript).filter(Transcript.video_id == video_id).first()
    if not row: raise HTTPException(404, "Transcript not generated")
    return {"video_id":video_id,"text":row.text}

@app.get("/videos/{video_id}/summary")
def summary(video_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    row = db.query(Summary).filter(Summary.video_id == video_id).first()
    if not row: raise HTTPException(404, "Summary not generated")
    return {"video_id":video_id,"short_summary":row.short_summary,
            "detailed_summary":row.detailed_summary,"keywords":row.keywords.split(",") if row.keywords else []}

@app.get("/videos/{video_id}/key-moments")
def key_moments(video_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = db.query(KeyMoment).filter(KeyMoment.video_id == video_id).all()
    return [{"timestamp":r.timestamp,"title":r.title,"description":r.description} for r in rows]

@app.post("/videos/{video_id}/bookmark")
def bookmark(video_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    exists = db.query(Bookmark).filter_by(user_id=user.id, video_id=video_id).first()
    if not exists:
        db.add(Bookmark(user_id=user.id, video_id=video_id))
        db.commit()
    return {"bookmarked": True}

@app.get("/dashboard/stats")
def dashboard_stats(db: Session = Depends(get_db), user=Depends(get_current_user)):
    videos_count = db.query(Video).count()
    bookmarks = db.query(Bookmark).filter_by(user_id=user.id).count()
    activities = db.query(Activity).filter_by(user_id=user.id).count()
    summaries = db.query(Summary).count()
    return {"videos":videos_count,"bookmarks":bookmarks,
            "activities":activities,"summaries":summaries}

@app.get("/admin/users")
def admin_users(db: Session = Depends(get_db), user=Depends(require_roles("admin"))):
    return [user_data(u) for u in db.query(User).all()]

def user_data(u):
    return {"id":u.id,"full_name":u.full_name,"email":u.email,"role":u.role}

def video_data(v):
    return {"id":v.id,"title":v.title,"filename":v.filename,
            "url":f"/uploads/{v.filename}","owner_id":v.owner_id,
            "status":v.status,"created_at":v.created_at.isoformat() if v.created_at else None}
